#Exercise
#1
setwd("C:\\Users\\it24102298\\Desktop\\IT24102298")
branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
fix(branch_data)
attach(branch_data)
#2
str(branch_data)

#3
boxplot(branch_data$Sales_X1, Main="Sales",outline=TRUE, outpch=8, horizontal=TRUE,
        xlab="Sales")
hist(branch_data$Sales_X1, Main="Sales",outline=TRUE,outpch=8, horizontal=TRUE)

#4
summary(Advertising_X2)
IQR(Advertising_X2)

#5
get.outlier <-function(x){
  q1<-quantile(x)[2]
  q3<-quantile(x)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers =", paste(sort(x[x<lb | x>ub]),collapse=",")))
}
get.outlier(Years_X3)
